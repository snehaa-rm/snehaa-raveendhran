package com.gnucash.GNU_Constants;

public interface GnuStrings {

    String defaultCurrency_Expected = "USD - US Dollar";
    String accountName_Expected = "SAVINGS";
    String savingsAccountDescription = "Adding Savings Account";
    String accountNameNoDescription_Expected = "Loan";
    String noAcctNameInlineErrorMsg_Expected = "Enter an account name to create an account";
    String newAccountName_Expected = "Salary";
    String AccountNameUpdated_Expected = "Account";
    String subAccountName_Expected = "Education";
    String subAccountDescription_Expected = "Education Savings";
    String transactionName_Expected = "Loan Payment";
    String transactionDescription_Expected = "Transaction for loan";
}
